using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace addressbook_web_test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
